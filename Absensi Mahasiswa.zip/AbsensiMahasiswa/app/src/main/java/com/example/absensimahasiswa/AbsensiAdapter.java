package com.example.absensimahasiswa;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class AbsensiAdapter extends RecyclerView.Adapter<AbsensiAdapter.ViewHolder> {
    private JSONArray data;

    public AbsensiAdapter(JSONArray data) {
        this.data = data;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Pastikan ini adalah file XML yang benar!
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_absen, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        try {
            JSONObject item = data.getJSONObject(position);
            holder.tvWaktu.setText("Waktu: " + item.getString("waktu_absen"));
            holder.tvStatus.setText("Status: " + item.getString("status"));

            // --- TOMBOL HAPUS ---
            holder.btnHapus.setOnClickListener(v -> {
                Toast.makeText(v.getContext(), "Tombol diklik", Toast.LENGTH_SHORT).show();
                try {
                    String idData = item.getString("id"); // Pastikan data JSON punya field 'id'
                    String url = "http://192.168.123.7/api_absensi/delete_absensi.php";                    StringRequest request = new StringRequest(Request.Method.POST, url,
                            response -> {
                                Toast.makeText(v.getContext(), response, Toast.LENGTH_LONG).show();
                                // Jika sukses, paksa Activity untuk refresh
                                if(response.trim().equalsIgnoreCase("success")) {
                                    if (v.getContext() instanceof android.app.Activity) {
                                        ((android.app.Activity) v.getContext()).recreate();
                                    }
                                } else {
                                    android.widget.Toast.makeText(v.getContext(), "Gagal hapus: " + response, android.widget.Toast.LENGTH_SHORT).show();
                                }
                            },
                            error -> android.widget.Toast.makeText(v.getContext(), "Error koneksi", android.widget.Toast.LENGTH_SHORT).show()) {
                        @Override
                        protected Map<String, String> getParams() {
                            Map<String, String> params = new HashMap<>();
                            params.put("id", idData); // Harus sesuai dengan POST di PHP
                            return params;
                        }
                    };
                    com.android.volley.toolbox.Volley.newRequestQueue(v.getContext()).add(request);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            });
            // --------------------

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        return data.length();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvWaktu, tvStatus;
        Button btnHapus;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvWaktu = itemView.findViewById(R.id.tvWaktu);
            tvStatus = itemView.findViewById(R.id.tvStatus);
            btnHapus = itemView.findViewById(R.id.btnHapus); // Pastikan ID ini ada di XML
        }
    }
}