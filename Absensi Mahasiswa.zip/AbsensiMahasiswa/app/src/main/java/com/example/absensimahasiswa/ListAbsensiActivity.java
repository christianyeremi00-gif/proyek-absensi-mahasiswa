package com.example.absensimahasiswa;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.android.volley.Request;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;

public class ListAbsensiActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    // Sesuaikan IP dengan laptop kamu
    String url = "http://192.168.123.7/api_absensi/get_absensi.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_absensi);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        getData();
    }

    private void getData() {
        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url, null,
                response -> {
                    AbsensiAdapter adapter = new AbsensiAdapter(response);
                    recyclerView.setAdapter(adapter);
                },
                error -> {
                    // Bisa tambahkan Toast error di sini
                });
        Volley.newRequestQueue(this).add(request);
    }
}