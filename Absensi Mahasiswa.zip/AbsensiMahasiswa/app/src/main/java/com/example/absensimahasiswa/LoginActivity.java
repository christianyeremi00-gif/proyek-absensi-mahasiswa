package com.example.absensimahasiswa;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast; // Tambahkan import ini
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    EditText etNim, etPassword;
    Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etNim = findViewById(R.id.etNim);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(v -> {
            String nim = etNim.getText().toString();
            String password = etPassword.getText().toString();

            // --- INTEGRASI SESSION MANAGER ---
            // 1. Simpan session setelah login sukses
            SessionManager session = new SessionManager(LoginActivity.this);
            session.createLoginSession(nim);

            // 2. Beri notifikasi ke user
            Toast.makeText(this, "Login Berhasil!", Toast.LENGTH_SHORT).show();

            // 3. Pindah ke MainActivity
            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        });
    }
}