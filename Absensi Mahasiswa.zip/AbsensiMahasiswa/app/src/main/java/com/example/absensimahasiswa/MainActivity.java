package com.example.absensimahasiswa;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private EditText etNim, etIdMk;
    private Spinner spStatus;
    private Button btnAbsen, btnLihatRiwayat;

    private static final String URL_ABSEN = "http://192.168.123.7/api_absensi/submit_absen.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // --- PENJAGA GERBANG (SESSION LOGIN) ---
        SessionManager session = new SessionManager(this);
        if (!session.isLoggedIn()) {
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
            finish();
            return;
        }
        // ----------------------------------------

        etNim = findViewById(R.id.etNim);
        etIdMk = findViewById(R.id.etIdMk);
        spStatus = findViewById(R.id.spStatus);
        btnAbsen = findViewById(R.id.btnAbsen);
        btnLihatRiwayat = findViewById(R.id.btnLihatRiwayat);

        btnAbsen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                kirimDataAbsen();
            }
        });

        btnLihatRiwayat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ListAbsensiActivity.class);
                startActivity(intent);
            }
        });
    }

    private void kirimDataAbsen() {
        final String nim = etNim.getText().toString().trim();
        final String idMk = etIdMk.getText().toString().trim();
        final String status = spStatus.getSelectedItem().toString();

        if (nim.isEmpty() || idMk.isEmpty()) {
            Toast.makeText(this, "NIM dan ID Matakuliah gak boleh kosong!", Toast.LENGTH_SHORT).show();
            return;
        }

        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL_ABSEN,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(MainActivity.this, response, Toast.LENGTH_LONG).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(MainActivity.this, "Koneksi Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("nim", nim);
                params.put("id_mk", idMk);
                params.put("status", status);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
}