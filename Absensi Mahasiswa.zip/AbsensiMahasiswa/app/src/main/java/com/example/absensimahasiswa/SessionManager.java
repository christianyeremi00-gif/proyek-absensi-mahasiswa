package com.example.absensimahasiswa;

import android.content.Context;
import android.content.SharedPreferences;

public class SessionManager {
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    Context context;

    public SessionManager(Context context) {
        this.context = context;
        pref = context.getSharedPreferences("user_session", Context.MODE_PRIVATE);
        editor = pref.edit();
    }

    public void createLoginSession(String nim) {
        editor.putBoolean("isLoggedIn", true);
        editor.putString("nim", nim);
        editor.apply(); // Gunakan apply() untuk performa lebih baik
    }

    public boolean isLoggedIn() {
        return pref.getBoolean("isLoggedIn", false);
    }

    public String getUserNim() {
        return pref.getString("nim", "");
    }

    public void logout() {
        editor.clear();
        editor.apply();
    }
}