package com.example.absensimahasiswa;

import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.android.volley.Request;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

public class AbsensiActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    String nimLogin = "123456789";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_absensi);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        loadDataAbsensi();
    }

    private void loadDataAbsensi() {
        String url = "http://10.0.2.2/api_absensi/get_absensi.php?nim=" + nimLogin;

        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url, null,
                response -> {
                    AbsensiAdapter adapter = new AbsensiAdapter(response);
                    recyclerView.setAdapter(adapter);
                },
                error -> Toast.makeText(AbsensiActivity.this, "Gagal ambil data: " + error.getMessage(), Toast.LENGTH_SHORT).show());

        Volley.newRequestQueue(AbsensiActivity.this).add(request);
    }
}